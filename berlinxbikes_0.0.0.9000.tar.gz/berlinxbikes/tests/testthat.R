library(testthat)
library(berlinxbikes)

test_check("berlinxbikes")
